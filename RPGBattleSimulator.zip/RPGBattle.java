import java.util.Random;
import java.util.Scanner;

class Character {
    String name;
    int maxHP;
    int currentHP;
    int attack;
    int defense;

    public Character(String name, int hp, int attack, int defense) {
        this.name = name;
        this.maxHP = hp;
        this.currentHP = hp;
        this.attack = attack;
        this.defense = defense;
    }

    public boolean isAlive() {
        return currentHP > 0;
    }

    public void takeDamage(int dmg) {
        currentHP -= dmg;
        if (currentHP < 0) currentHP = 0;
    }

    public void heal(int amount) {
        currentHP += amount;
        if (currentHP > maxHP) currentHP = maxHP;
    }

    public int dealDamage() {
        Random rand = new Random();
        return attack + rand.nextInt(6) - 2;
    }
}

public class RPGBattle {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Character player = new Character("Hero", 100, 20, 5);
        Character enemy = new Character("Goblin", 70, 15, 3);
        System.out.println("Battle Start!");

        while (player.isAlive() && enemy.isAlive()) {
            System.out.println("\nYour HP: " + player.currentHP + " | Goblin HP: " + enemy.currentHP);
            System.out.println("Choose action: 1) Attack 2) Heal");
            String input = scanner.nextLine();

            if (input.equals("1")) {
                int damage = Math.max(0, player.dealDamage() - enemy.defense);
                enemy.takeDamage(damage);
                System.out.println("You dealt " + damage + " damage to the Goblin!");
            } else if (input.equals("2")) {
                player.heal(20);
                System.out.println("You healed for 20 HP.");
            } else {
                System.out.println("Invalid input.");
                continue;
            }

            if (enemy.isAlive()) {
                int damage = Math.max(0, enemy.dealDamage() - player.defense);
                player.takeDamage(damage);
                System.out.println("Goblin dealt " + damage + " damage to you!");
            }
        }

        if (player.isAlive()) {
            System.out.println("\nYou defeated the Goblin!");
        } else {
            System.out.println("\nYou were defeated.");
        }
        scanner.close();
    }
}